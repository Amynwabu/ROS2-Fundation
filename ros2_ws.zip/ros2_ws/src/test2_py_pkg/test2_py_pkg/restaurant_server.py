#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from my_interfaces.srv import TakeOrder


class RestaurantServer(Node):
    def __init__(self):
        super().__init__('restaurant_server')

        # Create a service server for /take_order
        self.srv = self.create_service(
            TakeOrder,
            '/take_order',
            self.handle_order
        )

        self.get_logger().info('🍽️  Restaurant is OPEN! Waiting for orders...')

    def handle_order(self, request, response):
        # SERVER CALLBACK: Called when a client sends a request
        self.get_logger().info(f'📋 Incoming request: {request.quantity}x {request.item_name}')

        item = request.item_name.lower()

        if item == 'burger':
            response.accepted = True
            response.message = f'✅ Delicious! {request.quantity} burgers coming up!'
        elif item == 'salad':
            response.accepted = True
            response.message = '✅ Healthy choice! Salad on the way.'
        elif item == 'pizza':
            response.accepted = True
            response.message = f'✅ Amazing! {request.quantity} pizzas coming up!'
        elif item == 'fries':
            response.accepted = True
            response.message = '✅ Crispy fries on the way!'
        elif item == 'ice_cream':
            response.accepted = True
            response.message = '✅ Cool dessert! Ice cream coming up.'
        elif item == 'bread':
            response.accepted = True
            response.message = f'✅ Fresh bread! {request.quantity} loaves coming up.'
        else:
            response.accepted = False
            response.message = f'❌ Sorry, we do not serve {request.item_name}.'

        self.get_logger().info(f'📤 Sending response: {response.message}')

        return response


def main(args=None):
    rclpy.init(args=args)
    node = RestaurantServer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
