// generated from rosidl_generator_c/resource/idl.h.em
// with input from my_interfaces:srv/TakeOrder.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__TAKE_ORDER_H_
#define MY_INTERFACES__SRV__TAKE_ORDER_H_

#include "my_interfaces/srv/detail/take_order__struct.h"
#include "my_interfaces/srv/detail/take_order__functions.h"
#include "my_interfaces/srv/detail/take_order__type_support.h"

#endif  // MY_INTERFACES__SRV__TAKE_ORDER_H_
