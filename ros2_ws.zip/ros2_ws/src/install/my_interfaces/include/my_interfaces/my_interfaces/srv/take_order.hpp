// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__TAKE_ORDER_HPP_
#define MY_INTERFACES__SRV__TAKE_ORDER_HPP_

#include "my_interfaces/srv/detail/take_order__struct.hpp"
#include "my_interfaces/srv/detail/take_order__builder.hpp"
#include "my_interfaces/srv/detail/take_order__traits.hpp"
#include "my_interfaces/srv/detail/take_order__type_support.hpp"

#endif  // MY_INTERFACES__SRV__TAKE_ORDER_HPP_
