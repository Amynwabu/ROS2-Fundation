// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from my_interfaces:srv/TakeOrder.idl
// generated code does not contain a copyright notice

#ifndef MY_INTERFACES__SRV__DETAIL__TAKE_ORDER__BUILDER_HPP_
#define MY_INTERFACES__SRV__DETAIL__TAKE_ORDER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "my_interfaces/srv/detail/take_order__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_TakeOrder_Request_quantity
{
public:
  explicit Init_TakeOrder_Request_quantity(::my_interfaces::srv::TakeOrder_Request & msg)
  : msg_(msg)
  {}
  ::my_interfaces::srv::TakeOrder_Request quantity(::my_interfaces::srv::TakeOrder_Request::_quantity_type arg)
  {
    msg_.quantity = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::TakeOrder_Request msg_;
};

class Init_TakeOrder_Request_item_name
{
public:
  Init_TakeOrder_Request_item_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TakeOrder_Request_quantity item_name(::my_interfaces::srv::TakeOrder_Request::_item_name_type arg)
  {
    msg_.item_name = std::move(arg);
    return Init_TakeOrder_Request_quantity(msg_);
  }

private:
  ::my_interfaces::srv::TakeOrder_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::TakeOrder_Request>()
{
  return my_interfaces::srv::builder::Init_TakeOrder_Request_item_name();
}

}  // namespace my_interfaces


namespace my_interfaces
{

namespace srv
{

namespace builder
{

class Init_TakeOrder_Response_message
{
public:
  explicit Init_TakeOrder_Response_message(::my_interfaces::srv::TakeOrder_Response & msg)
  : msg_(msg)
  {}
  ::my_interfaces::srv::TakeOrder_Response message(::my_interfaces::srv::TakeOrder_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::my_interfaces::srv::TakeOrder_Response msg_;
};

class Init_TakeOrder_Response_accepted
{
public:
  Init_TakeOrder_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_TakeOrder_Response_message accepted(::my_interfaces::srv::TakeOrder_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_TakeOrder_Response_message(msg_);
  }

private:
  ::my_interfaces::srv::TakeOrder_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::my_interfaces::srv::TakeOrder_Response>()
{
  return my_interfaces::srv::builder::Init_TakeOrder_Response_accepted();
}

}  // namespace my_interfaces

#endif  // MY_INTERFACES__SRV__DETAIL__TAKE_ORDER__BUILDER_HPP_
