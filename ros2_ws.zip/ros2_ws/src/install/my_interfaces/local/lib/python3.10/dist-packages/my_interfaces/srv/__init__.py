from my_interfaces.srv._take_order import TakeOrder  # noqa: F401
